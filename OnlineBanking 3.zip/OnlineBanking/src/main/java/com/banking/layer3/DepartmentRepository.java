package com.banking.layer3;

import java.util.List;

import com.banking.layer2.Department;

public interface DepartmentRepository {
	
	public void insertDepartment(Department dept); //C
	
	public Department		selectDepartmentById(int deptNumber);
	public List<Department> selectAllDepartmets();
	
	public void updateDepartment(Department dept); //U
	public void deleteDepartment(int deptNumber);  //D
	
	
}
