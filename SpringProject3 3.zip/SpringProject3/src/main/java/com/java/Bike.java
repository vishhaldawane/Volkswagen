package com.java;

public class Bike {

	public Bike() {
		// TODO Auto-generated constructor stub
		System.out.println("Bike Ctor...");
	}

}
