package com.banking;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/dept")
public class DepartmentController {
	
	private List<Department> deptList = new ArrayList<Department>(); //global
	
	public DepartmentController() {
		System.out.println("DepartmentController: DepartmentController() ctor...");
		
		Department deptObj1 = new Department(10,"IT","New York");
		Department deptObj2 = new Department(20,"Test","New Jersey");
		Department deptObj3 = new Department(30,"Sales","New Delhi");
		Department deptObj4 = new Department(40,"Operations","New Mumbai");
		
		deptList.add(deptObj1);
		deptList.add(deptObj2);
		deptList.add(deptObj3);
		deptList.add(deptObj4);
		
	}

	@GetMapping("/getDepts") // http://localhost:8080/dept/getDepts
	public List<Department>  getAllDepartments() {
		System.out.println("DepartmentController: /dept/getDepts/");

		return deptList;
		
	}
	
	@GetMapping("/getDept/{dno}") // http://localhost:8080/dept/getDept/10
	public Department getDepartment(@PathVariable("dno") int deptno) {
		System.out.println("DeptController : /dept/getDept/{dno}");
		
		boolean found = false;
		Department deptFound = null;
		
		for(Department dept : deptList) {
			
			if(dept.getDepartmentNumber() == deptno ) {
				found = true;
				deptFound = dept;
				break;
				
			}
		}
		
		if(found)	{
			
			System.out.println("dept : "+deptFound.getDepartmentName());
			return deptFound;
		}
		else
			return null;
	}
}
