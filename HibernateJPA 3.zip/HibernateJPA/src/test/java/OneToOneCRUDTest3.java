import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.entity.Department;
import com.java.one2one.Passport;
import com.java.one2one.Person;

public class OneToOneCRUDTest3 {
	
	
	
	
	@Test
	public void insertPerson() {
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
			Person person = new Person(); //new/blank entity object 
			person.setPersonName("Smith");
			entityManager.persist(person); //generate the insert query for us 
		transaction.commit();
	}
	
	@Test
	public void insertPassport() {
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
			Passport passport = new Passport(); //new/blank entity object 
			passport.setIssuedBy("Govt.Of India");
			passport.setIssueDate(LocalDate.of(2021, 12, 25));
			passport.setExpiryDate(LocalDate.of(2031, 12, 25));
		
			entityManager.persist(passport); //generate the insert query for us 
		transaction.commit();
	}
	
	@Test
	void assignExistingPassportToExistingPerson()
	{
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
	
		
				Person person 	  = entityManager.find(Person.class, 69);
				Passport passport = entityManager.find(Passport.class, 65);
				
				person.setPassport(passport);// are we setting the FK?
				passport.setPerson(person); // are we setting the FK?
				
				entityManager.merge(person);
				entityManager.merge(passport);
				
		transaction.commit();		
		
	}
}





