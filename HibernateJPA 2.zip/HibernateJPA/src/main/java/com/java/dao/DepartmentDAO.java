package com.java.dao;

public interface DepartmentDAO {
	//5 methods for CRUD - C R RA U D
}
