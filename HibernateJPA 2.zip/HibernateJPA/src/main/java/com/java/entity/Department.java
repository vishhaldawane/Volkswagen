package com.java.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity //mandatory
@Table(name="DEPT") // this is the table name mapped with the Department class
public class Department { //1. POJO/entity is done
	
	@Id //mandatory  - to declare the column name below is a primary key
	@Column(name="deptno") //physical/real column name of the table
	private int departmentNumber;
	
	@Column(name="dname")
	private String departmentName;
	
	@Column(name="loc")
	private String departmentLocation;
	
	//java.time.*
	//LocalDate dateOfJoining,   birthdate, hiredate, shipdate, orderdate....
	//LocalDateTime
	
	public int getDepartmentNumber() {
		return departmentNumber;
	}
	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getDepartmentLocation() {
		return departmentLocation;
	}
	public void setDepartmentLocation(String departmentLocation) {
		this.departmentLocation = departmentLocation;
	}
	
	
	
}
