package com.banking;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController // to generate REpresentational State Transfer  JSON, HTML, XML ....
@RequestMapping("/bank") // URI
public class Greeting {
	
	@RequestMapping("/services") //nested URI
	public String[] bankServices() { // localhost:8080/bank/services
		String ourServices[] = {"Personal Banking","Fixed Deposits","PPF"};
		return ourServices;
	}

	@RequestMapping("/greet") //nested URI
	public String greetMe() { // localhost:8080/bank/greet
		return "Welcome to Online Banking";
	}
	
	@RequestMapping("/bye") //nested URI
	public String logoutMe() { // localhost:8080/bank/bye
		return "Hope you liked the bankning services...";
	}
}

/*



Piyush Ingle, [Online Examination ]
Priyank Bhardwaj, 
Prasid C, 
Saurabh Loya,
Vedant Mishra,
Vaibhav Pardhi
Ananya M


Prabhat Ranjan , [ Bus Reservation ]
Ankit Verma , 
Rudresh Pradhan,  
Sonali , 
Shweta,
Vishal G


Sahil Mulla,
Abhijeet Bhavankar, Sanika Kudtarkar, Ayush Sonu, Rushikesh Jadhav, Anshul Saini

Tilawat, Riddhik
Mohit MakhijaIshan MandlikSiddi DeshmukeRiddhik TilawatAbhas OmarAbhir Mahajan





 
 */ 
