package com.java.dao;

public interface DepartmentDAO {

}
