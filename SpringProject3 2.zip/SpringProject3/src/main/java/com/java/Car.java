package com.java;

public class Car {

	Engine theEngine;
	
	public Car(Engine theEngine) { //dependency upon the Engine Object
		// TODO Auto-generated constructor stub
		this.theEngine = theEngine;
	}
	
	public void startTheCar() {
		System.out.println("Starting the Car...");
		theEngine.igniteEngine();
		System.out.println("------------");
	}

}
