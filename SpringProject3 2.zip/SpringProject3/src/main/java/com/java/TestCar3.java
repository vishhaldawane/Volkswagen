package com.java;

import org.springframework.context.ApplicationContext; //container
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCar3 {

	public static void main(String[] args) {
		
	
		ApplicationContext container = new  ClassPathXmlApplicationContext("SpringConfig.xml");
		
		Car theCar1 = container.getBean(Car.class,"myCar");
				
		theCar1.startTheCar();
		
	}

}
