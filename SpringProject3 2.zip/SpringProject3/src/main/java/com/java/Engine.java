package com.java;

public class Engine {

	Piston pist; //hasA
	
	public Engine(Piston pist) { //here is the dependency upon the piston object
		// TODO Auto-generated constructor stub
		this.pist = pist;
	}
	
	public void igniteEngine() {
		System.out.println("Ingiting the engine....");
		pist.firePiston();
	}

}
