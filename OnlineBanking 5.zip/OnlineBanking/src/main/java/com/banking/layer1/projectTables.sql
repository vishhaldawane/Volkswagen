create table dept
(
    deptno int primary key,
    dname varchar(20),
    loc varchar(20)
);

