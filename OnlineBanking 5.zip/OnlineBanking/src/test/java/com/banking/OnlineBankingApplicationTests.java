package com.banking;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.banking.layer2.Department;
import com.banking.layer3.DepartmentRepository;

@SpringBootTest
class OnlineBankingApplicationTests {

	@Autowired
	DepartmentRepository deptRepo;
	
	@Test
	void showAllDepartmentsTest() {
		List<Department> deptList =  deptRepo.selectAllDepartmets();
		
		for(Department theDept : deptList) {
			System.out.println("Dept Number   : "+theDept.getDepartmentNumber());
			System.out.println("Dept Name     : "+theDept.getDepartmentName());
			System.out.println("Dept Location : "+theDept.getDepartmentLocation());
			System.out.println("---------------");
		}
	}

}
