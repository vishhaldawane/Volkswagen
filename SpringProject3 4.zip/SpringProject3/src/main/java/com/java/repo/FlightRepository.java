package com.java.repo;

import java.util.List;

import com.java.Flight;

public interface FlightRepository { //repository [ spring ] is same as DAO [ core java ]
	List<Flight> getAvailableFlights();
}
