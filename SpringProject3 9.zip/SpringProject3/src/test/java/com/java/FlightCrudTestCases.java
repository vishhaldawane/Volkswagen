package com.java;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.java.repo.FlightRepository;
import com.java.repo.exceptions.FlightAlreadyPresentException;
@ExtendWith(SpringExtension.class) 
@ContextConfiguration(locations = {"classpath:SpringConfig3.xml"}) //copied in src/main/resources
public class FlightCrudTestCases {

	@Autowired
	@Qualifier("flightRepoImpl3")
	FlightRepository flightRepo ;
	
	@Test
	public void updateFlightTest() {
		
		Flight newFlight = new Flight();
		newFlight.setFlightNumber(101); //existing number
		newFlight.setFlightName("IndianAirlines"); //current value is ai
		newFlight.setSource("MUMBAI"); //current value is mumbai
		newFlight.setDestination("New York"); //current val
		flightRepo.updateFlight(newFlight);
		
	}
	//drop the flights table, and run below test case
	@Test
	public void addNewFlight() {
		Flight newFlight = new Flight();
		newFlight.setFlightNumber(108);
		newFlight.setFlightName("Emirates");
		newFlight.setSource("Mumbai");
		newFlight.setDestination("Dubai");
		newFlight.setFlightDepartureDate(LocalDateTime.of(2021, 12, 25, 15, 45));
		try {
			flightRepo.insertFlight(newFlight);
		} catch (FlightAlreadyPresentException e) {
			System.out.println("Problem : "+e.getMessage());
		//	e.printStackTrace();
		}
	}

}
