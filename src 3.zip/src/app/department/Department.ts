export class Department {
    departmentNumber: number=0 ;
	departmentName: string | undefined;
	departmentLocation: string | undefined;
}