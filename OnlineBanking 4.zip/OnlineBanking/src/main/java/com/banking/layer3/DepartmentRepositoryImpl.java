package com.banking.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.banking.layer2.Department;

@Repository
public class DepartmentRepositoryImpl implements DepartmentRepository {

	
	@PersistenceContext
	EntityManager entityManager; //1. PersistenceContext.createEMF("MyJPA"); 2. EMF.createEM()
	
	@Override
	public void insertDepartment(Department dept) {
		// TODO Auto-generated method stub

	}

	@Override
	public Department selectDepartmentById(int deptNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Department> selectAllDepartmets() {
		System.out.println("Departmentrepository: selectAllDepartmets");
		TypedQuery<Department> query = entityManager.createQuery("from Department", Department.class);
		return query.getResultList();	
	}

	@Override
	public void updateDepartment(Department dept) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteDepartment(int deptNumber) {
		// TODO Auto-generated method stub

	}

}
