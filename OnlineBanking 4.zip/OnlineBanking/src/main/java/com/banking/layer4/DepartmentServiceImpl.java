package com.banking.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.layer2.Department;
import com.banking.layer3.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	
	@Autowired
	DepartmentRepository deptRepo;
	
	public void createDepartmentService(Department dept) {
		// TODO Auto-generated method stub

	}

	
	public Department findDepartmentByIdService(int deptNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public List<Department> findAllDepartmetsService() {
		System.out.println("DepartmentService: findAllDepartmetsService");
		return deptRepo.selectAllDepartmets(); //service is invoking repo
	}


	public void modifyDepartmentService(Department dept) {
		// TODO Auto-generated method stub

	}

	
	public void removeDepartmentService(int deptNumber) {
		// TODO Auto-generated method stub

	}

}
