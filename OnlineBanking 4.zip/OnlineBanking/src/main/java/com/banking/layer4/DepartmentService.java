package com.banking.layer4;

import java.util.List;

import com.banking.layer2.Department;

public interface DepartmentService {

	public void createDepartmentService(Department dept); //C
	
	public Department		findDepartmentByIdService(int deptNumber);
	public List<Department> findAllDepartmetsService();
	
	public void modifyDepartmentService(Department dept); //U
	public void removeDepartmentService(int deptNumber);  //D
}
