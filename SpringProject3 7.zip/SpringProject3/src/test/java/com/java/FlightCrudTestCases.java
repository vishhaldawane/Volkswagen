package com.java;

import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.java.repo.FlightRepository;

public class FlightCrudTestCases {

	@Test
	public void updateFlightTest() {
		// TODO Auto-generated constructor stub
		
		ApplicationContext container = new  
				ClassPathXmlApplicationContext("SpringConfig3.xml");
		System.out.println("container...created : "+container);
		
		FlightRepository flightRepo = (FlightRepository) container.getBean("flightRepoImpl3");	
		System.out.println("flightRepo : "+flightRepo);
		
		Flight newFlight = new Flight();
		newFlight.setFlightNumber(101); //existing number
		newFlight.setFlightName("AirIndia"); //current value is ai
		newFlight.setSource("MUMBAI"); //current value is mumbai
		newFlight.setDestination("NEW DELHI"); //current val
		flightRepo.updateFlight(newFlight);
		
	}

}
