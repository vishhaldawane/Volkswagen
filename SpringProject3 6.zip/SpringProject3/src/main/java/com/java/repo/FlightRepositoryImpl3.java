package com.java.repo;
//spring with JDBC
//spring with ORM/JPA
//spring Transactions

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.java.Flight;

@Repository("flightRepoImpl3") // same like @Component 
public class FlightRepositoryImpl3 implements FlightRepository {

	@PersistenceContext
	private EntityManager entityManager; //inject the EntityManager's object
	
	public FlightRepositoryImpl3() {
		System.out.println("FlightRepositoryImpl3() ctor...");
	}
	
	public List<Flight> getAvailableFlights() {
		System.out.println("FlightRepositoryImpl3: getAvailableFlights()");
		List<Flight> flightList = new ArrayList<Flight>(); //let me be on mute
	
		flightList = entityManager.createQuery("from Flight").getResultList() ;//from Pojo
	
		return flightList;
	}

	@Transactional //no need of EntityTransaction, begin and commit/rollback
	public void insertFlight(Flight flight) {
		entityManager.persist(flight);
		System.out.println("inserted...the flight");
	}
}
