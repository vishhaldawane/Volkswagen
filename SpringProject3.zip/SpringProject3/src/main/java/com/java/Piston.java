package com.java;

public class Piston {

	String type;
	
	public Piston(String type) { //here is the dependency upon the String object
		// TODO Auto-generated constructor stub
		this.type = type;
	}
	
	void firePiston() {
		System.out.println(type+ " piston is fired....");
	}

}
