import { Component, OnInit } from '@angular/core';
import { DepartmentService } from '../department.service';
import { Department } from './Department';
import { Employee } from './Employee';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {

 
  deptObj: Department = new Department();
  /*deptArray: Department[] = [
    {"departmentNumber":100,"departmentName":"IT","departmentLocation":"NY"},
    {"departmentNumber":200,"departmentName":"Test","departmentLocation":"NJ"},
    {"departmentNumber":300,"departmentName":"QMS","departmentLocation":"ND"},
    {"departmentNumber":400,"departmentName":"Operations","departmentLocation":"NM"}
  ];*/

  deptArray: Department[]=[] ;

  ngOnInit(): void {
    
  }
  constructor(private deptService: DepartmentService) { }

  getAllDepartments() //this is called on click of the button
  {
    console.log('getAllDepartments()--> invoking getAllDepartmentsService()...');
    this.deptService.getAllDepartmentsService().subscribe(
      (data: Department[])=> //srping data is pushed into this data variable
      {
        this.deptArray = data; //assign data to allFriends so that html can fetch it in tr td tags
        console.log(this.deptArray);
      }, 
      (err) => {
        console.log(err);
      }
    ); 
  }


saveDepartment() {
  console.log('saveDepartment()--> invoking saveDepartmentService()...');
  this.deptService.saveDepartmentService(this.deptObj).subscribe(
    (data: Department)=> //srping data is pushed into this data variable
    {
      this.deptObj = data; //assign data to allFriends so that html can fetch it in tr td tags
      console.log(this.deptObj);
      this.getAllDepartments();//refresh the array
    }, 
    (err) => {
      console.log(err);
    }
  ); 
}
updateDepartment() {
  console.log('updateDepartment()--> invoking updateDepartmentService()...');
  this.deptService.updateDepartmentService(this.deptObj).subscribe(
    (data: Department)=> //srping data is pushed into this data variable
    {
      this.deptObj = data; //assign data to allFriends so that html can fetch it in tr td tags
      console.log(this.deptObj);
      this.getAllDepartments();//refresh the array
    }, 
    (err) => {
      console.log(err);
    }
  ); 
}

updateDepartmentByDeptObject(deptToUpdate: Department) {
  console.log('updateDepartment()--> invoking updateDepartmentService()...'+deptToUpdate.departmentNumber);
  this.deptService.updateDepartmentService(deptToUpdate).subscribe(
    (data: Department)=> //srping data is pushed into this data variable
    {
      this.deptObj = data; //assign data to allFriends so that html can fetch it in tr td tags
      console.log(this.deptObj);
      this.getAllDepartments();//refresh the array
    }, 
    (err) => {
      console.log(err);
    }
  ); 
}

deptNumberToDelete: number=0;

deleteDepartment() {
  console.log('deleteDepartment()--> invoking deleteDepartmentService()...');
  this.deptService.deleteDepartmentService(this.deptNumberToDelete).subscribe(
    (data: Department)=> //srping data is pushed into this data variable
    {
      this.deptObj = data; //assign data to allFriends so that html can fetch it in tr td tags
      console.log(this.deptObj);
      this.getAllDepartments();//refresh the array
    }, 
    (err) => {
      console.log(err);
    }
  ); 
}

deleteDepartmentByDeptno(deptNumber: number) {
  console.log('deleteDepartment()--> invoking deleteDepartmentService()...'+deptNumber);
  this.deptService.deleteDepartmentService(deptNumber).subscribe(
    (data: Department)=> //srping data is pushed into this data variable
    {
      this.deptObj = data; //assign data to allFriends so that html can fetch it in tr td tags
      console.log(this.deptObj);
      this.getAllDepartments();//refresh the array
    }, 
    (err) => {
      console.log(err);
    }
  ); 
}

updateEmployee(empObj: Employee) {
  console.log('updating employee...'+empObj.empNumber);
}

deleteEmployee(empNumber: number) {
  console.log('deleting employee...'+empNumber);
}


}