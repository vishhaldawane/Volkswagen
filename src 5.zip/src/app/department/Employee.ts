export class Employee {
	  empNumber: number=0;	
	  empName : string | undefined;
	  empSalary : number =0;
      deptno: number=0;
}