import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Department } from './department/Department';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  constructor(private myHttp: HttpClient) { }

  getAllDepartmentsService() : Observable<Department[]> 
  {
    console.log('getAllDepartmentsService() invoked...');
    return this.myHttp.get<Department[]>("http://localhost:8080/deptJPA/getDepts");
  }

  saveDepartmentService(newDept: Department) {
    console.log('saveDepartmentService() invoked...');
    return this.myHttp.post<Department>("http://localhost:8080/deptJPA/addDeptBody",newDept);
  }
  updateDepartmentService(newDept: Department) {
    console.log('updateDepartmentService() invoked...');
    return this.myHttp.put<Department>("http://localhost:8080/deptJPA/updateDept",newDept);

  }
}
