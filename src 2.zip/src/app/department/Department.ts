export class Department {
    departmentNumber: number | undefined;
	departmentName: string | undefined;
	departmentLocation: string | undefined;
}