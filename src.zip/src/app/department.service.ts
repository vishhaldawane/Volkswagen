import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Department } from './department/Department';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  constructor(private myHttp: HttpClient) { }

  getAllDepartmentsService() : Observable<Department[]> 
  {
    console.log('getAllDepartmentsService() invoked...');
    return this.myHttp.get<Department[]>("http://localhost:8080/deptJPA/getDepts");
  }
}
