package com.banking.layer5;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
/*
 * 
 * 1 - tables						DONE
 * 2 - entity - pojo				DONE
 * 3 - repo + repoImpl				
 * 4 - service + serviceImpl
 * 5 - controller
 * 6 - angular UI
 */

import com.banking.layer2.Department;
import com.banking.layer4.DepartmentService;

@CrossOrigin
@RestController
@RequestMapping("/deptJPA")
public class DepartmentJPAController {
	
	@Autowired
	DepartmentService deptService;
	
	private List<Department> deptList = new ArrayList<Department>(); //global
	
	public DepartmentJPAController() {
		System.out.println("DepartmentJPAController: DepartmentJPAController() ctor...");
	
		
	}
	
	
	@GetMapping("/getDepts") // http://localhost:8080/deptJPA/getDepts
	public List<Department>  getAllDepartments() {
		System.out.println("DepartmentController: /dept/getDepts/");
		return deptService.findAllDepartmetsService(); //controller is invoking service
		
	}
	
	@GetMapping("/getDept/{dno}") // http://localhost:8080/dept/getDept/10
	public Department getDepartment(@PathVariable("dno") int deptno) {
		System.out.println("DeptController : /dept/getDept/{dno}");

		return deptService.findDepartmentByIdService(deptno);
	}
	

	//open postman, create new request, select GET, enter 3 values as line number 70
	@GetMapping("/addDept/{dno}/{dname}/{loc}") // http://localhost:8080/dept/addDept/88/Test/Pune
	public Department  addDepartment(@PathVariable("dno") int deptno, 
									 @PathVariable("dname") String deptName,
									 @PathVariable("loc") String deptLoc) {
		System.out.println("DepartmentController: /dept/addDept/"+deptno+" "+deptName+" "+deptLoc);
		Department tempDept = new Department(deptno,deptName,deptLoc);
		deptList.add(tempDept);
		return tempDept;
		
	}
	
	
	//open postman, create new request, select POST, enter request BODY, send
	@PostMapping("/addDeptBody") // http://localhost:8080/dept/addDeptBody
	public Department  addDepartmentBody(@RequestBody Department newDept) {
		System.out.println("DepartmentController: /dept/addDeptBody/"+newDept.getDepartmentNumber()+" "+newDept.getDepartmentName()+" "+newDept.getDepartmentLocation());

		deptService.createDepartmentService(newDept);
		return newDept;
		
	}
	
	@PutMapping("/updateDept") // http://localhost:8080/dept/updateDept
	public Department updateDepartment(@RequestBody Department deptToUpdate) {
		System.out.println("DeptController : /dept/updateDept/");
		
		
		deptService.modifyDepartmentService(deptToUpdate);
		return deptToUpdate;
	}
	
	@DeleteMapping("/deleteDept/{dno}") // http://localhost:8080/dept/updateDept
	public Department deleteDepartment(@PathVariable("dno") int deptNo) {
		System.out.println("DeptController : /dept/deleteDept/");
		
		return deptService.removeDepartmentService(deptNo);
	}
	
	
	
}
