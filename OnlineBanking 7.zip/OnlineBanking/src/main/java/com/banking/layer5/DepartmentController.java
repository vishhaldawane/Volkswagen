package com.banking.layer5;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.banking.layer2.Department;

@RestController
@RequestMapping("/dept")
public class DepartmentController {
	
	private List<Department> deptList = new ArrayList<Department>(); //global
	
	public DepartmentController() {
		System.out.println("DepartmentController: DepartmentController() ctor...");
		
		Department deptObj1 = new Department(10,"IT","New York");
		Department deptObj2 = new Department(20,"Test","New Jersey");
		Department deptObj3 = new Department(30,"Sales","New Delhi");
		Department deptObj4 = new Department(40,"Operations","New Mumbai");
		
		deptList.add(deptObj1);
		deptList.add(deptObj2);
		deptList.add(deptObj3);
		deptList.add(deptObj4);
		
	}

	@GetMapping("/getDepts") // http://localhost:8080/dept/getDepts
	public List<Department>  getAllDepartments() {
		System.out.println("DepartmentController: /dept/getDepts/");

		return deptList;
		
	}
	
	@GetMapping("/getDept/{dno}") // http://localhost:8080/dept/getDept/10
	public Department getDepartment(@PathVariable("dno") int deptno) {
		System.out.println("DeptController : /dept/getDept/{dno}");
		
		boolean found = false;
		Department deptFound = null;
		
		for(Department dept : deptList) {
			
			if(dept.getDepartmentNumber() == deptno ) {
				found = true;
				deptFound = dept;
				break;
				
			}
		}
		
		if(found)	{
			
			System.out.println("dept : "+deptFound.getDepartmentName());
			return deptFound;
		}
		else
			return null;
	}
	

	//open postman, create new request, select GET, enter 3 values as line number 70
	@GetMapping("/addDept/{dno}/{dname}/{loc}") // http://localhost:8080/dept/addDept/88/Test/Pune
	public Department  addDepartment(@PathVariable("dno") int deptno, 
									 @PathVariable("dname") String deptName,
									 @PathVariable("loc") String deptLoc) {
		System.out.println("DepartmentController: /dept/addDept/"+deptno+" "+deptName+" "+deptLoc);
		Department tempDept = new Department(deptno,deptName,deptLoc);
		deptList.add(tempDept);
		return tempDept;
		
	}
	
	
	//open postman, create new request, select POST, enter request BODY, send
	@PostMapping("/addDeptBody") // http://localhost:8080/dept/addDeptBody
	public Department  addDepartmentBody(@RequestBody Department newDept) {
		System.out.println("DepartmentController: /dept/addDeptBody/"+newDept.getDepartmentNumber()+" "+newDept.getDepartmentName()+" "+newDept.getDepartmentLocation());

		deptList.add(newDept);
		return newDept;
		
	}
	
	@PutMapping("/updateDept") // http://localhost:8080/dept/updateDept
	public Department updateDepartment(@RequestBody Department deptToUpdate) {
		System.out.println("DeptController : /dept/updateDept/");
		
		boolean found = false;
		
		
		for(int i=0;i<deptList.size();i++) {
			
			Department tempDept = deptList.get(i);
			
			if(tempDept.getDepartmentNumber() == deptToUpdate.getDepartmentNumber() ) {
				deptList.remove(i); //remove the matching object
				deptList.add(deptToUpdate); //and replace it with this NEW one
				found=true;
				break;
			}
		}
		
		if(found)	{
			
			System.out.println("updated dept : "+deptToUpdate.getDepartmentName());
			return deptToUpdate;
		}
		else
			return null;
	}
	
	@DeleteMapping("/deleteDept/{dno}") // http://localhost:8080/dept/updateDept
	public Department deleteDepartment(@PathVariable("dno") int deptNo) {
		System.out.println("DeptController : /dept/deleteDept/");
		
		boolean found = false;
		
		Department tempDept = null;
		
		for(int i=0;i<deptList.size();i++) {
			
			tempDept = deptList.get(i);
			
			if(tempDept.getDepartmentNumber() == deptNo ) {
				deptList.remove(i); //remove the matching object
				
				found=true;
				break;
			}
		}
		
		if(found)	{
			
			System.out.println("updated dept : "+deptNo);
			return tempDept;
		}
		else
			return null;
	}
	
	
	
}
