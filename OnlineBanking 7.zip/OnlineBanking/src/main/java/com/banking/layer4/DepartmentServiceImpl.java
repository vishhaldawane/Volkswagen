package com.banking.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.banking.layer2.Department;
import com.banking.layer3.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	
	@Autowired
	DepartmentRepository deptRepo;
	
	public Department createDepartmentService(Department dept) {
		// TODO Auto-generated method stub
		return deptRepo.insertDepartment(dept);
	}

	
	public Department findDepartmentByIdService(int deptNumber) {
		// TODO Auto-generated method stub
		return deptRepo.selectDepartmentById(deptNumber);
	}

	
	public List<Department> findAllDepartmetsService() {
		System.out.println("DepartmentService: findAllDepartmetsService");
		return deptRepo.selectAllDepartmets(); //service is invoking repo
	}


	public Department modifyDepartmentService(Department dept) {
		return deptRepo.updateDepartment(dept);

	}

	
	public Department removeDepartmentService(int deptNumber) {
		return deptRepo.deleteDepartment(deptNumber);

	}

}
