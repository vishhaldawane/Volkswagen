package com.banking.layer4;

import java.util.List;

import com.banking.layer2.Department;

public interface DepartmentService {

	public Department createDepartmentService(Department dept); //C
	
	public Department		findDepartmentByIdService(int deptNumber);
	public List<Department> findAllDepartmetsService();
	
	public Department modifyDepartmentService(Department dept); //U
	public Department removeDepartmentService(int deptNumber);  //D
}
