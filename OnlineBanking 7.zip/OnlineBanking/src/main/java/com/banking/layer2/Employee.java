package com.banking.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="EMPLOYEE8")
public class Employee {

	
	@Id
	@Column(name="EMPNUMBER")
	private int empNumber;
	
	@Column(name="EMPNAME")
	private String empName;
	
	@Column(name="EMPSALARY")
	private Float empSalary;
	
	@ManyToOne
	@JoinColumn(name="DEPTNO") // FK for emp table
	private Department dept;
	
	//OneToMany
	//Set<BankAccount> bank
	
	public Employee(int empNumber, String empName, Float empSalary, Department dept) {
		super();
		this.empNumber = empNumber;
		this.empName = empName;
		this.empSalary = empSalary;
		this.dept = dept;
	}


	public Employee() {
		// TODO Auto-generated constructor stub
	}


	public int getEmpNumber() {
		return empNumber;
	}




	public void setEmpNumber(int empNumber) {
		this.empNumber = empNumber;
	}




	public String getEmpName() {
		return empName;
	}




	public void setEmpName(String empName) {
		this.empName = empName;
	}




	public Float getEmpSalary() {
		return empSalary;
	}




	public void setEmpSalary(Float empSalary) {
		this.empSalary = empSalary;
	}



//u have to suppress this methods output for the UI
	
	@JsonIgnore
	public Department getDept() {
		return dept;
	}

//DEVTOOLS DEPENDENCY TO UPDATE THE SPRING CONTAINER...AS U SAVE ANY FILE


	public void setDept(Department dept) {
		this.dept = dept;
	}





}
